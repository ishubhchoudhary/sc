// Add Student Record
function add_student(){
    var name = document.getElementById('name').value;
	var email = document.getElementById('email').value;
	var address = document.getElementById('address').value;
	var profile = document.getElementById('profile').value;

	if(name === '' || email === '' || address === '' || profile === ''){
		alert('Please Fill All The Fields');
		return false;
	}else{
		var formdata = {
			'name' : name,
			'email' : email,
			'address' : address,
			'profile' : profile
		}

		jsondata = JSON.stringify(formdata);
        // console.log(jsondata);

        // ------
            var form_value = new FormData();
            form_value.append('form', jsondata);
            var files = $('#profile')[0].files[0];
            form_value.append('file',files);
            form_value.append('img_upload',files);
            
        // ------
         
        // ----------------------------------------------------------------------------
        // // formData.append('file', document.getElementById("profile").files[0]);
		// const fileInput = document.getElementById("profile").value;
		// const selectedFiles = fileInput.files;
		
		// for (let i = 0; i < selectedFiles.length; i++) {
		// 	formData.append("file[]", selectedFiles[i]);
		// }
		//   console.log([...formData])
        // ----------------------------------------------------------------------------

        // -------------------
            // var data = new FormData();
            // var files = $('#profile')[0].files[0];
            // data.append('file',files);
            // console.log(data);
        // -------------------

        $.ajax({
            url: url+'add-student',
            type: 'post',
            dataType: 'json',
            data: form_value,
            enctype: 'multipart/form-data',            
            contentType: false,
            cache : false,
            processData: false, 
            success: function(data){
                loadMoreData();
                console.log(data);
                // var details=data.records;   
                // var page_link=data.page_link; 
               
                // var total_records=data.total_records;  
                   
                // $("#pagination-div-id").html(page_link);
                // $('#pagination-div-id a').each(function () {
                //     var a=$(this).attr("href");
                //     $(this).attr("onclick",'pagination("'+a+'")');
                //     $(this).attr("href","javascript:void(0)");
                // }); 
    
                // var html="";
                // var details_length=details.length;
                // for(i=0;i<details_length;i++)
                // {                   
                //     if(compare_session.search(details[i].diamond_id)>=0){
                //         text_color="text-red";
                //         compare_title="Remove From Compare"
                //     }else{
                //         text_color="";
                //         compare_title="Add To Compare";
                //     }
    
                //     if(details[i].stock_id != null){ var stock_id=details[i].stock_id; }else{ var stock_id=""; }
                //     if(details[i].shape_full != null){ var shape=details[i].shape_full; }else{ var shape=""; }
                //     if(details[i].weight != null){ var weight=parseFloat(details[i].weight).toFixed(2); }else{ var weight=""; }
                //     if(details[i].color != null){ var color=details[i].color; }else{ var color=""; }
                //     if(details[i].grade != null){ var grade=details[i].grade; }else{ var grade=""; }
                //     if(details[i].cut_full != null){ var cut=details[i].cut_full; }else{ var cut=""; }
                //     if(details[i].polish_full != null){ var polish=details[i].polish_full; }else{ var polish=""; }
                //     if(details[i].symmetry_full != null){ var symmetry=details[i].symmetry_full; }else{ var symmetry=""; }
                //     if(details[i].fluor_full != null){ var fluorescence_int=details[i].fluor_full; }else{ var fluorescence_int=""; }
                //     if(details[i].rapnet_discount != null){ var rapnet_discount=parseFloat(details[i].rapnet_discount).toFixed(1); }else{ var rapnet_discount=""; }
                //     if(details[i].depth != null){ var depth=parseFloat(details[i].depth).toFixed(1); }else{ var depth=""; }
                //     if(details[i].table_d != null){ var table_d=parseInt(details[i].table_d); }else{ var table_d=""; }
                //     if(details[i].cost_carat != null){ var cost_carat=Math.round(details[i].cost_carat); }else{ var cost_carat=""; }
                //     if(details[i].total_price != null){ var total_price=Math.round(details[i].total_price); }else{ var total_price=""; }
                //     if(details[i].lab != null){ var lab=details[i].lab; }else{ var lab=""; }
                //     if(details[i].measurements != null){ var measurements=details[i].measurements; }else{ var measurements=""; }
                //     if(details[i].cash_price != null){ var cash_price=details[i].cash_price; }else{ var cash_price=""; }
    
                //     html +='<tr style="font-size:12px; font-weight:bold;" id="tr_'+details[i].diamond_id+'">';
                //     html +=' <td>';
                //     html +='      <input type="checkbox" name="checkbox_record[]" value="'+details[i].diamond_id+'" class="tr_checkbox pull-left" >';
                //     html +='        <a href="javascript:void(0)" onclick="add_compare('+details[i].diamond_id+')" ><i class="fa fa-exchange '+text_color+'" title="'+compare_title+'" id="fa_compare_'+details[i].diamond_id+'" data-toggle="tooltip" data-placement="right" aria-hidden="true"></i></a>';
                //     html +='    </td>';
                //     html +='    <td> ';
                //     html +='      <a href="'+base_url+'diamond-details/'+details[i].diamond_id+'">';                          
                //     html +='        <i class="fa fa-search-plus"  title="View details" data-toggle="tooltip" data-placement="right"></i>';
                //     html +='      </a>';
                //     html +='    </td>';
                //     html +='    <td>'+stock_id +'</td>';
                //     html +='    <td class="text-uppercase">'+shape +'</td>';
                //     html +='    <td>'+weight+' </td>';
                //     html +='    <td>'+color+' </td>';
                //     html +='    <td>'+grade+' </td>';
                //     html +='    <td>'+cut+' </td>';
                //     html +='    <td>'+polish+' </td>';
                //     html +='    <td>'+symmetry+'</td>';
                //     html +='    <td>'+fluorescence_int+'</td>';
                //     html +='    <td>'+depth+'</td>';
                //     html +='    <td>'+table_d+'</td>';
                //     html +='    <td>$'+cash_price+'</td>  ';
                //     html +='    <td>$'+total_price+'</td>  ';
                //     html +='    <td><span title="'+lab+'" data-toggle="tooltip">';
                //     html +=lab;                                        
                //     html +='</span></td>'; 
                //     if(details[i].vendor_id == 8){ 
                //      html += '    <td> ';
                // html += '       <a target="_blank" onclick="dnaOpen_belgiumny('+stock_id+')" ">';
                // html += '        <img src="' + base_url + 'assets/images/camera.png"  data-toggle="tooltip" style="margin: 0;" height="auto" width="20px">';
                // html += '      </a>';
                // html += '    </td>'; 
                // } else{
                //      html += '    <td> ';
                // html += '       <a target="_blank" onclick="dnaOpen('+stock_id+')" ">';
                // html += '        <img src="' + base_url + 'assets/images/camera.png"  data-toggle="tooltip" style="margin: 0;" height="auto" width="20px">';
                // html += '      </a>';
                // html += '    </td>';  
                // }                 
                //     html +='    <td>'+measurements+'</td>';                    
                //     html +='</tr>';
    
                // }
    
                // $('#example').dataTable().fnDestroy();
    
                // $("#total_records").html(total_records);
                // $("#add_data").html(html);
    
                // $('#example').DataTable({                    
                //     "retrieve": true, 
                //     "autoWidth": false ,               
                //     "scrollY": '800',  
                //     "scrollX": true,
                //     "ordering": true,
                //     "paging": false,
                //     "searching": false,
                //     "info": false,           
                //     "order": []                                               
                // });
    
            },
            // beforeSend: function () {
            //     $("#page-loader").show();
            // },
            // complete: function () {
            //     $("#page-loader").fadeOut();
            //     $('[data-toggle="tooltip"]').tooltip(); 
            // }    
    
        });
	}
}

loadMoreData();
function loadMoreData(){ 
    $.ajax({
        url: url+'load-more-data',
        dataType: 'json',
        type: 'post',            
        data: {}, 
        success: function(data){
            var details=data.records;   
            console.log(details);
            // var page_link=data.page_link; 
           
            // var total_records=data.total_records;  
               
            // $("#pagination-div-id").html(page_link);
            // $('#pagination-div-id a').each(function () {
            //     var a=$(this).attr("href");
            //     $(this).attr("onclick",'pagination("'+a+'")');
            //     $(this).attr("href","javascript:void(0)");
            // }); 

            var html="";
            var details_length=details.length;
            for(i=0;i<details_length;i++)
            {                   
                if(details[i].id != null){ var id=details[i].id; }else{ var id=""; }
                if(details[i].name != null){ var name=details[i].name; }else{ var name=""; }
                if(details[i].email != null){ var email=details[i].email; }else{ var email=""; }
                if(details[i].address != null){ var address=details[i].address; }else{ var address=""; }
                if(details[i].profile != null){ var profile=details[i].profile; }else{ var profile=""; }
       
                 html += `
                 <tr> 
                    <td>${name}</td>
                    <td>${email}</td>
                    <td>${address}</td>
                    <td>${profile}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-toggle="modal"
                            data-target="#editStudentModal" onclick="editStudent(${id})">
                            <i class="fas fa-edit"></i>
                        </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(${id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        
                    </td>
                </tr>`;
          
            }                 
            // $('#example').dataTable().fnDestroy();

            // $("#total_records").html(total_records);
            $("#add_data").html(html);

            // $('#example').DataTable({                    
            //     "retrieve": true, 
            //     "autoWidth": false ,               
            //     "scrollY": '800',  
            //     "scrollX": true,
            //     "ordering": true,
            //     "paging": false,
            //     "searching": false,
            //     "info": false,           
            //     "order": []                                               
            // });

        },
        // beforeSend: function () {
        //     $("#page-loader").show();
        // },
        // complete: function () {
        //     $("#page-loader").fadeOut();
        //     $('[data-toggle="tooltip"]').tooltip(); 
        // }    

    });
}

function deleteStudent(id){
    $.ajax({
        url: url+'delete-student',
        dataType: 'json',
        type: 'post',            
        data: {'student_id' : id}, 
        success: function(data){
            loadMoreData();
        }

    });
}

function editStudent(id){ 
    $.ajax({
        url: url+'edit-student',
        dataType: 'json',
        type: 'post',            
        data: {'id':id}, 
        success: function(data){
            var details=data.records;
            console.log(details);
            var html="";
            var details_length=details.length;
            for(i=0;i<details_length;i++)
            {                   
                if(details[i].id != null){ var id=details[i].id; }else{ var id=""; }
                if(details[i].name != null){ var name=details[i].name; }else{ var name=""; }
                if(details[i].email != null){ var email=details[i].email; }else{ var email=""; }
                if(details[i].address != null){ var address=details[i].address; }else{ var address=""; }
                if(details[i].profile != null){ var profile=details[i].profile; }else{ var profile=""; }
                
                $("#student_id").val(id);
                $("#editName").val(name);
                $("#editEmail").val(email);
                $("#editAddress").val(address);
            }
        }
    });
}


function update_student(){
    var name = document.getElementById('editName').value;
	var email = document.getElementById('editEmail').value;
	var address = document.getElementById('editAddress').value;
	var profile = document.getElementById('editProfile').value;
	var student_id = document.getElementById('student_id').value;

	if(name === '' || email === '' || address === '' || profile === ''){
		alert('Please Fill All The Fields');
		return false;
	}else{
		var formdata = {
			'student_id' : student_id,
			'name' : name,
			'email' : email,
			'address' : address,
			'profile' : profile
		}

		jsondata = JSON.stringify(formdata);
            var form_value = new FormData();
            form_value.append('form', jsondata);
            var files = $('#editProfile')[0].files[0];
            form_value.append('file',files);
            form_value.append('img_upload',files);

        $.ajax({
            url: url+'update-student',
            type: 'post',
            dataType: 'json',
            data: form_value,
            enctype: 'multipart/form-data',            
            contentType: false,
            cache : false,
            processData: false, 
            success: function(data){
                loadMoreData();
                console.log(data);
            },
            // beforeSend: function () {
            //     $("#page-loader").show();
            // },
            // complete: function () {
            //     $("#page-loader").fadeOut();
            //     $('[data-toggle="tooltip"]').tooltip(); 
            // }    
    
        });
	}
}