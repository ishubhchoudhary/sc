<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_Ajax_Controller extends CI_Controller {

	public function __construct()
	{
	  parent::__construct();
	  $this->load->model('common_model'); 
		
	} 

	public function index()
	{
		$this->load->view('crud_ajax_view');
	}

	public function add_student()
	{
		if(empty($_FILES["img_upload"])){
			echo "Image is not uploaded";
		}else{
			$target_dir = "ftp_upload/students/images/";
			$target_file = $target_dir . basename($_FILES["img_upload"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			$status = 0;
			$message = '';

			// Check if file already exists
			// if (file_exists($target_file)) {
			// 	$message = "File already exist.";
			// }else 
			if ($_FILES["img_upload"]["size"] > 500000) {
				// Check file size
				$message = "File too large. Keep file size below 200KB.";
			}else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
				// Allow certain file formats
				$message = "Uploaded file is not an image.";
			}else{
				move_uploaded_file($_FILES["img_upload"]["tmp_name"], $target_file);
				$post = json_decode($_POST['form'], true);
				$name = $post['name'];
				$email = $post['email'];
				$address = $post['address'];
				$profile = $_FILES["img_upload"]["name"];

				$data = [
					'name' => $name,
					'email' => $email,
					'address' => $address,
					'profile' => $profile
				];

				$insert_id=$this->common_model->insertData('students',$data);
				$message = "Created Student Successfully";
				$status = 1;
			}
	
			echo json_encode([
				'message' => $message,
				'status' => $status,
				'data' => []
			]);
			
		}
	}

	public function loadMoreData()
	{
		$status = 1;
        $message = '';
		$records=$this->common_model->selectAll('students');
		echo json_encode([
			'message' => $message,
			'status' => $status,
			'records' => $records
		]);
	}

	public function delete_student(){
		$status = 1;
		$message = 'Deleted Successfully';

		$id = $this->input->post('student_id');
		$data = array(
			'id' => $id
		);

		$records=$this->common_model->deleteData('students', $data);

		echo json_encode([
			'message' => $message,
			'status' => $status,
			'records' => $records
		]);
	}

	public function edit_student()
	{
		$status = 1;
        $message = '';

		$id = $this->input->post('id');
		$data = array(
			'id' => $id
		);

		$records=$this->common_model->selectWhere('students', $data);
		echo json_encode([
			'message' => $message,
			'status' => $status,
			'records' => $records
		]);
	}

	public function update_student()
	{
		if(empty($_FILES["img_upload"])){
			echo "Image is not uploaded";
		}else{
			$target_dir = "ftp_upload/students/images/";
			$target_file = $target_dir . basename($_FILES["img_upload"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			$status = 0;
			$message = '';

			// Check if file already exists
			// if (file_exists($target_file)) {
			// 	$message = "File already exist.";
			// }else 
			if ($_FILES["img_upload"]["size"] > 500000) {
				// Check file size
				$message = "File too large. Keep file size below 200KB.";
			}else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
				// Allow certain file formats
				$message = "Uploaded file is not an image.";
			}else{
				move_uploaded_file($_FILES["img_upload"]["tmp_name"], $target_file);
				$post = json_decode($_POST['form'], true);
				$student_id = $post['student_id'];
				$name = $post['name'];
				$email = $post['email'];
				$address = $post['address'];
				$profile = $_FILES["img_upload"]["name"];

				$data = [
					'name' => $name,
					'email' => $email,
					'address' => $address,
					'profile' => $profile
				];

				$where = [
					'id' => $student_id 
				];


				$insert_id=$this->common_model->updateData('students',$data,$where);
				$message = "Updated Student Successfully";
				$status = 1;
			}
	
			echo json_encode([
				'message' => $message,
				'status' => $status,
				'data' => []
			]);
			
		}
	}
}