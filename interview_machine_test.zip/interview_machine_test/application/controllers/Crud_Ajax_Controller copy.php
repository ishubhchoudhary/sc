<?php

session_start();
 
error_reporting(E_ALL & ~ E_NOTICE);

class Controller
{
    function __construct() 
    {
        $this->processMobileVerification();
    }
    function processMobileVerification()
    {
       
                        $sid = $_POST['subcategories'];
                        $pid = rand(9999,1000);
                        $productname = $_POST['pname'];
                        $price = $_POST['price'];
                        $target_dir = "products-images/";
                        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
                        $uploadOk = 1;
                        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                        
                        // Check if image file is a actual image or fake image
                        
                          $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                          if($check !== false) {
                           
                            $uploadOk = 1;
                          } else {
                            
                            $uploadOk = 2;
                          }
                       
                        
                        // Check if file already exists
                        if (file_exists($target_file)) {
                          
                          $uploadOk = 3;
                        }
                        
                        // Check file size
                        if ($_FILES["fileToUpload"]["size"] > 500000) {
                          
                          $uploadOk = 4;
                        }
                        
                        // Allow certain file formats
                        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                          
                          $uploadOk = 5;
                        }
                        
                        // Check if $uploadOk is set to 0 by an error
                        if ($uploadOk == 5) {
                          echo 5;
                        } 
                        else if($uploadOk == 4){
                                echo 4;
                            }
                            else if($uploadOk == 3){
                                    echo 3;
                                }
                                else if($uploadOk == 2){
                                        echo 2;
                                    }
                        else {
                          if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                            $db = mysqli_connect('localhost', 'djtechbl', '(Sani@Vaar8)', 'djtechbl_projects');
                            $query= "INSERT INTO products (sid,pid,name,price,image1) VALUES('$sid','$pid','$productname','$price','$target_file')";
                            $result = mysqli_query($db,$query);
                            if(!$result){
                                die(mysqli_error());
                                echo 0;
                                exit();
                            }
                            else
                                echo 1;
                          } 
                          else {
                            echo 7;
                          }
                        }
                        
                        
     
 
    }
}
$controller = new Controller();
?>